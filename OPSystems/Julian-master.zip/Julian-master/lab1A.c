#include<stdio.h>

int main(){
  int i = 0;
  int sum = 0;

for(i = 1; i<=1717; i++){
  sum = i + sum;
 }
 printf("%d\n", sum);
}
