#include<stdio.h>
#include<stdlib.h>

int main(){
  
  for(int i = 0; i<=10; i++){
    printf("%d\n",rand()%100 + 1);
    
  }
  return 0;
  
}
