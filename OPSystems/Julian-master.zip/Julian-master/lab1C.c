int main(){
  int a, b, c, d, i;
  int* memo;
  while()
    if a != c || a != d || b != c || 
    

}
